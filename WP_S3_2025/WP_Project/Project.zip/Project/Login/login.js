function togglePassword() {
    var pwd = document.getElementById("password");
    pwd.type = (pwd.type === "password") ? "text" : "password";
}